import React from 'react'

function Body(props) {
  return (
    <div>
    
    <h2>
        {props.name}, {props.country} sunrise: {props.sunrise}, sunset: {props.sunset}
      </h2>
      <img src={props.pngIcon} />
      </div>
  )
}

export default Body